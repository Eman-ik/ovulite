import { useEffect, useState } from "react";
import {
  Users,
  TrendingUp,
  ShieldCheck,
  Filter,
  Award,
  Droplets,
  Sparkles,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts";
import IntelligenceFeed from "@/components/IntelligenceFeed";

type RawRecord = Record<string, string>;

type MetricCard = {
  title: string;
  value: string;
  change: string;
  progress: number;
  accent: string;
  icon: "records" | "rate" | "pregnancies" | "fresh" | "tech";
};

type ChartItem = {
  name: string;
  value: number;
  rate?: number;
  count?: number;
  color?: string;
};

type TechnicianItem = {
  name: string;
  transfers: number;
  pregnancies: number;
  successRate: number;
  avgGrade: number;
  avgCL: number;
};

const ACCENTS = ["#0ea5e9", "#8b5cf6", "#ec4899", "#10b981", "#f59e0b"];
const DAY_MS = 24 * 60 * 60 * 1000;

function cleanCell(value: string | undefined): string {
  return (value ?? "").replace(/^\uFEFF/, "").trim().replace(/^"|"$/g, "");
}

function parseCsv(content: string): string[][] {
  const rows: string[][] = [];
  const text = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  let currentCell = "";
  let currentRow: string[] = [];
  let inQuotes = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        currentCell += '"';
        index += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === "," && !inQuotes) {
      currentRow.push(currentCell);
      currentCell = "";
      continue;
    }

    if (char === "\n" && !inQuotes) {
      currentRow.push(currentCell);
      rows.push(currentRow);
      currentRow = [];
      currentCell = "";
      continue;
    }

    currentCell += char;
  }

  if (currentCell.length > 0 || currentRow.length > 0) {
    currentRow.push(currentCell);
    rows.push(currentRow);
  }

  return rows;
}

function rowToRecord(headers: string[], row: string[]): RawRecord {
  const record: RawRecord = {};
  headers.forEach((header, index) => {
    record[cleanCell(header)] = cleanCell(row[index]);
  });
  return record;
}

function parseDateValue(raw: string): Date | null {
  const value = cleanCell(raw);
  if (!value) return null;

  const direct = new Date(value);
  if (!Number.isNaN(direct.getTime())) return direct;

  const slashMatch = value.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{2,4})$/);
  if (slashMatch) {
    const month = Number(slashMatch[1]);
    const day = Number(slashMatch[2]);
    const year = Number(slashMatch[3].length === 2 ? `20${slashMatch[3]}` : slashMatch[3]);
    const parsed = new Date(year, month - 1, day);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
  }

  const monthMap: Record<string, number> = {
    jan: 0,
    feb: 1,
    mar: 2,
    apr: 3,
    may: 4,
    jun: 5,
    jul: 6,
    aug: 7,
    sep: 8,
    oct: 9,
    nov: 10,
    dec: 11,
  };

  const monthMatch = value.match(/^(\d{1,2})[-\/ ]([A-Za-z]{3})[-\/ ](\d{2,4})$/);
  if (monthMatch) {
    const day = Number(monthMatch[1]);
    const month = monthMap[monthMatch[2].toLowerCase()];
    const year = Number(monthMatch[3].length === 2 ? `20${monthMatch[3]}` : monthMatch[3]);
    const parsed = new Date(year, month, day);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
  }

  return null;
}

function parseNumber(raw: string): number | null {
  const value = cleanCell(raw).replace(/[^\d.-]/g, "");
  if (!value) return null;
  const parsed = Number(value);
  return Number.isNaN(parsed) ? null : parsed;
}

function parseGradeValue(raw: string): number | null {
  const value = cleanCell(raw);
  if (!value) return null;

  if (/^\d+,\d+$/.test(value)) {
    const parsed = Number(value.replace(",", "."));
    return Number.isNaN(parsed) ? null : parsed;
  }

  const match = value.match(/-?\d+(?:\.\d+)?/);
  if (!match) return null;
  const parsed = Number(match[0]);
  return Number.isNaN(parsed) ? null : parsed;
}

function pickFirst(record: RawRecord, keys: string[]): string {
  for (const key of keys) {
    const value = cleanCell(record[key]);
    if (value) return value;
  }
  return "";
}

function statusFromRecord(record: RawRecord): string {
  return pickFirst(record, ["Heat", "Status", "1st PC Result", "Pregnant Y/N"]).toLowerCase();
}

function isPregnant(record: RawRecord): boolean {
  const status = statusFromRecord(record);
  return /pregnan|confirmed|positive|yes/.test(status);
}

function isOpen(record: RawRecord): boolean {
  const status = statusFromRecord(record);
  return /open|no|recheck|negative/.test(status);
}

function bucketGrade(value: number | null): string {
  if (value === null) return "Unknown";
  if (value <= 2) return "1-2";
  if (value <= 4) return "3-4";
  if (value <= 6) return "5-6";
  return "7-8";
}

function monthLabel(date: Date): string {
  return `${date.toLocaleString("en-US", { month: "short" })} '${String(date.getFullYear()).slice(-2)}`;
}

function buildRecords(content: string): RawRecord[] {
  const rows = parseCsv(content).filter((row) => row.some((cell) => cleanCell(cell).length > 0));
  const headerIndex = rows.findIndex((row) => {
    const normalized = row.map((cell) => cleanCell(cell).toLowerCase());
    return normalized.some((cell) => cell.includes("et date")) && normalized.some((cell) => cell.includes("dip") || cell.includes("protocol") || cell.includes("status") || cell.includes("1st pc result"));
  });

  if (headerIndex < 0) return [];

  const headers = rows[headerIndex].map(cleanCell);
  const records: RawRecord[] = [];

  for (const row of rows.slice(headerIndex + 1)) {
    const firstCell = cleanCell(row[0]).toLowerCase();
    if (firstCell.startsWith("notes") || firstCell.startsWith("summary") || firstCell.startsWith("total")) {
      break;
    }

    const record = rowToRecord(headers, row);
    if (Object.values(record).some((value) => value.length > 0)) {
      records.push(record);
    }
  }

  return records;
}

function getTopTechnicians(records: RawRecord[]): TechnicianItem[] {
  const map = new Map<
    string,
    { transfers: number; pregnancies: number; gradeSum: number; gradeCount: number; clSum: number }
  >();

  records.forEach((record) => {
    const tech = pickFirst(record, ["ET Tech", "ET assistant", "ET Tech/assistant", "Technician"]) || "Unknown";
    const entry = map.get(tech) ?? { transfers: 0, pregnancies: 0, gradeSum: 0, gradeCount: 0, clSum: 0 };
    entry.transfers += 1;

    if (isPregnant(record)) entry.pregnancies += 1;

    const grade = parseGradeValue(pickFirst(record, ["Embryo Grade"]));
    if (grade !== null) {
      entry.gradeSum += grade;
      entry.gradeCount += 1;
    }

    const cl = parseNumber(pickFirst(record, ["CL measure (mm)"]));
    if (cl !== null) entry.clSum += cl;

    map.set(tech, entry);
  });

  return Array.from(map.entries())
    .map(([name, entry]) => ({
      name,
      transfers: entry.transfers,
      pregnancies: entry.pregnancies,
      successRate: entry.transfers ? (entry.pregnancies / entry.transfers) * 100 : 0,
      avgGrade: entry.gradeCount ? entry.gradeSum / entry.gradeCount : 0,
      avgCL: entry.transfers ? entry.clSum / entry.transfers : 0,
    }))
    .sort((a, b) => b.successRate - a.successRate || b.transfers - a.transfers)
    .slice(0, 5);
}

function getDashboardData(records: RawRecord[]) {
  const datedRecords = records
    .map((record) => ({ record, date: parseDateValue(pickFirst(record, ["ET Date", "Date"])) }))
    .filter((entry): entry is { record: RawRecord; date: Date } => Boolean(entry.date));

  const totalTransfers = records.length;
  const pregnancyCount = records.filter((record) => isPregnant(record)).length;
  const openCount = records.filter((record) => isOpen(record)).length;
  const pregnancyRate = totalTransfers ? (pregnancyCount / totalTransfers) * 100 : 0;

  const grades = records
    .map((record) => parseGradeValue(pickFirst(record, ["Embryo Grade"])))
    .filter((value): value is number => value !== null);
  const avgGrade = grades.length ? grades.reduce((sum, value) => sum + value, 0) / grades.length : 0;

  const freshCount = records.filter((record) => /fresh/i.test(pickFirst(record, ["Fresh or Frozen"]))).length;
  const frozenCount = records.filter((record) => /frozen/i.test(pickFirst(record, ["Fresh or Frozen"]))).length;

  const latestDate = datedRecords.reduce((latest, entry) => (entry.date > latest ? entry.date : latest), datedRecords[0]?.date ?? new Date());
  const monthMap = new Map<string, { date: Date; pregnant: number; total: number }>();

  datedRecords.forEach((entry) => {
    const key = monthLabel(entry.date);
    const bucket = monthMap.get(key) ?? { date: new Date(entry.date.getFullYear(), entry.date.getMonth(), 1), pregnant: 0, total: 0 };
    bucket.total += 1;
    if (isPregnant(entry.record)) bucket.pregnant += 1;
    monthMap.set(key, bucket);
  });

  const monthlyData = Array.from(monthMap.entries())
    .sort((a, b) => a[1].date.getTime() - b[1].date.getTime())
    .map(([month, value]) => ({
      month,
      rate: value.total ? Number(((value.pregnant / value.total) * 100).toFixed(1)) : 0,
      count: value.total,
      pregnant: value.pregnant,
    }));

  const protocolMap = new Map<string, { total: number; pregnant: number }>();
  records.forEach((record) => {
    const protocol = pickFirst(record, ["Protocol", "Semen type", "Protocol Name"]) || "Unknown";
    const bucket = protocolMap.get(protocol) ?? { total: 0, pregnant: 0 };
    bucket.total += 1;
    if (isPregnant(record)) bucket.pregnant += 1;
    protocolMap.set(protocol, bucket);
  });

  const protocolData = Array.from(protocolMap.entries())
    .map(([name, value]) => ({
      name,
      rate: value.total ? Number(((value.pregnant / value.total) * 100).toFixed(1)) : 0,
      count: value.total,
    }))
    .sort((a, b) => b.rate - a.rate || b.count - a.count)
    .slice(0, 6);

  const gradeBuckets = new Map<string, { total: number; pregnant: number }>();
  records.forEach((record) => {
    const grade = parseGradeValue(pickFirst(record, ["Embryo Grade"]));
    const bucket = bucketGrade(grade);
    const entry = gradeBuckets.get(bucket) ?? { total: 0, pregnant: 0 };
    entry.total += 1;
    if (isPregnant(record)) entry.pregnant += 1;
    gradeBuckets.set(bucket, entry);
  });

  const gradeData = Array.from(gradeBuckets.entries()).map(([name, value]) => ({
    name,
    value: value.total ? Number(((value.pregnant / value.total) * 100).toFixed(1)) : 0,
    count: value.total,
  }));

  const distributionData: ChartItem[] = [
    freshCount > 0 ? { name: "Fresh", value: freshCount, color: ACCENTS[0] } : null,
    frozenCount > 0 ? { name: "Frozen", value: frozenCount, color: ACCENTS[1] } : null,
  ].filter(Boolean) as ChartItem[];

  if (!distributionData.length && totalTransfers > 0) {
    distributionData.push({ name: "All Transfers", value: totalTransfers, color: ACCENTS[2] });
  }

  const technicians = getTopTechnicians(records);
  const topTechnician = technicians[0];

  const metrics: MetricCard[] = [
    {
      title: "Total ET Records",
      value: totalTransfers.toString(),
      change: `${records.length ? "100" : "0"}% coverage`,
      progress: records.length ? 100 : 0,
      accent: ACCENTS[0],
      icon: "records",
    },
    {
      title: "Pregnancy Rate",
      value: `${pregnancyRate.toFixed(1)}%`,
      change: `${pregnancyCount}/${totalTransfers || 0}`,
      progress: Math.round(pregnancyRate),
      accent: ACCENTS[1],
      icon: "rate",
    },
    {
      title: "Confirmed Pregnancies",
      value: pregnancyCount.toString(),
      change: `${openCount} open cases`,
      progress: totalTransfers ? Math.round((pregnancyCount / totalTransfers) * 100) : 0,
      accent: ACCENTS[2],
      icon: "pregnancies",
    },
    {
      title: "Fresh Transfers",
      value: freshCount.toString(),
      change: totalTransfers ? `${Math.round((freshCount / totalTransfers) * 100)}% of pool` : "0% of pool",
      progress: totalTransfers ? Math.round((freshCount / totalTransfers) * 100) : 0,
      accent: ACCENTS[3],
      icon: "fresh",
    },
    {
      title: "Top Technician",
      value: topTechnician?.name ?? "Unknown",
      change: topTechnician ? `${topTechnician.successRate.toFixed(1)}% success` : "No data",
      progress: topTechnician ? Math.round(topTechnician.successRate) : 0,
      accent: ACCENTS[4],
      icon: "tech",
    },
  ];

  return {
    metrics,
    monthlyData,
    distributionData,
    protocolData,
    gradeData,
    technicians,
    avgGrade,
    pregnancyRate,
    latestDate,
  };
}

function timeFilteredRecords(records: RawRecord[], timePeriod: "all" | "week" | "month") {
  if (!records.length) return records;

  const dated = records
    .map((record) => ({ record, date: parseDateValue(pickFirst(record, ["ET Date", "Date"])) }))
    .filter((entry): entry is { record: RawRecord; date: Date } => Boolean(entry.date));

  if (!dated.length || timePeriod === "all") return records;

  const latest = dated.reduce((current, entry) => (entry.date > current ? entry.date : current), dated[0].date);
  const cutoff = new Date(latest.getTime() - (timePeriod === "week" ? 7 : 30) * DAY_MS);

  return dated.filter((entry) => entry.date >= cutoff).map((entry) => entry.record);
}

const mintPanelStyle = {
  background: "#daf1de",
  border: "1px solid rgba(1, 69, 58, 0.08)",
  boxShadow: "0 30px 90px rgba(1, 69, 58, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.42)",
};

export default function AdminDashboard() {
  const [timePeriod, setTimePeriod] = useState<"all" | "week" | "month">("month");
  const [records, setRecords] = useState<RawRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [dashboard, setDashboard] = useState(() => getDashboardData([]));

  useEffect(() => {
    const load = async () => {
      try {
        setIsLoading(true);
        setLoadError(null);
        const response = await fetch("/datasets/ET%20Summary%20-%20ET%20Data.csv");
        if (!response.ok) {
          throw new Error(`Failed to load dataset (${response.status})`);
        }
        const text = await response.text();
        setRecords(buildRecords(text));
      } catch (error) {
        console.error("Failed to load ET dataset", error);
        setLoadError("Unable to load the ET dataset from /datasets/ET Summary - ET Data.csv.");
        setRecords([]);
      } finally {
        setIsLoading(false);
      }
    };

    load();
  }, []);

  useEffect(() => {
    const filtered = timeFilteredRecords(records, timePeriod);
    setDashboard(getDashboardData(filtered));
  }, [records, timePeriod]);

  const latestLabel = dashboard.latestDate
    ? dashboard.latestDate.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    : "No date available";

  return (
    <div
      className="min-h-screen p-6 lg:p-10 text-white"
      style={{
        background:
          "radial-gradient(circle at top left, rgba(14, 165, 233, 0.18), transparent 35%), radial-gradient(circle at top right, rgba(139, 92, 246, 0.16), transparent 28%), linear-gradient(180deg, #03191c 0%, #031f2b 40%, #07111d 100%)",
      }}
    >
      <div className="mx-auto max-w-[1440px] space-y-10">
        <header className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs uppercase tracking-[0.28em] text-white/70 backdrop-blur-xl">
              <SparkleBadge />
              Biotech Intelligence Suite
            </div>
            <div>
              <h1 className="text-4xl font-semibold tracking-tight text-white lg:text-5xl">ET Admin Intelligence Dashboard</h1>
              <p className="mt-2 max-w-2xl text-sm text-white/65 lg:text-base">
                Premium glassmorphism analytics built from the live ET dataset, with monthly trend, distribution,
                protocol, grade, and technician views.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-3 py-3 backdrop-blur-2xl">
            <Filter className="h-5 w-5 text-cyan-300" />
            {(["all", "week", "month"] as const).map((period) => (
              <button
                key={period}
                onClick={() => setTimePeriod(period)}
                className={`rounded-xl px-4 py-2 text-sm font-medium transition-all duration-200 ${
                  timePeriod === period
                    ? "bg-white text-slate-950 shadow-[0_10px_30px_rgba(56,189,248,0.25)]"
                    : "text-white/70 hover:bg-white/8 hover:text-white"
                }`}
              >
                {period === "all" ? "All Time" : period === "week" ? "7 Days" : "30 Days"}
              </button>
            ))}
          </div>
        </header>

        <section className="rounded-2xl border border-[#01453a]/10 bg-[#daf1de] p-5 shadow-[0_22px_80px_rgba(1,69,58,0.12)] backdrop-blur-[30px] lg:p-6">
          <div className="flex flex-col gap-2 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-[#01453a]/70">Intelligence Feed</p>
              <h2 className="mt-2 text-xl font-semibold text-[#01453a]">Live ET activity stream</h2>
            </div>
            <p className="text-sm text-[#01453a]/60">Dataset source: {latestLabel}</p>
          </div>
          <div className="mt-4 rounded-2xl border border-[#01453a]/10 bg-white/55 p-3">
            <IntelligenceFeed />
          </div>
        </section>

        {loadError ? (
          <div className="rounded-2xl border border-rose-400/30 bg-rose-400/10 p-4 text-sm text-rose-100">
            {loadError}
          </div>
        ) : null}

        <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-5">
          {dashboard.metrics.map((metric, index) => (
            <MetricPanel key={metric.title} metric={metric} iconIndex={index} />
          ))}
        </section>

        <section className="grid grid-cols-1 gap-6 xl:grid-cols-7">
          <div
            className="rounded-3xl p-6 lg:col-span-4 lg:p-7"
            style={{
              background: "#daf1de",
              border: "1px solid rgba(1, 69, 58, 0.08)",
              boxShadow: "0 30px 90px rgba(1, 69, 58, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.42)",
            }}
          >
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-xs uppercase tracking-[0.28em] text-[#01453a]/70">Monthly Trend</p>
                <h3 className="mt-2 text-2xl font-semibold text-[#01453a]">Pregnancy rate over time</h3>
              </div>
              <div className="rounded-full border border-[#01453a]/10 bg-white/55 px-3 py-2 text-xs text-[#01453a]/70">
                {dashboard.monthlyData.length} monthly points
              </div>
            </div>

            <div className="mt-6 h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={dashboard.monthlyData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="monthlyGlow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#01453a" stopOpacity={0.28} />
                      <stop offset="55%" stopColor="#01453a" stopOpacity={0.16} />
                      <stop offset="100%" stopColor="#01453a" stopOpacity={0.04} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="month" stroke="rgba(1,69,58,0.65)" tickLine={false} axisLine={false} />
                  <YAxis
                    stroke="rgba(1,69,58,0.65)"
                    tickLine={false}
                    axisLine={false}
                    domain={[0, 100]}
                    tickFormatter={(value) => `${value}%`}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "rgba(255, 255, 255, 0.96)",
                      border: "1px solid rgba(1,69,58,0.12)",
                      borderRadius: 16,
                      color: "#01453a",
                      boxShadow: "0 16px 60px rgba(1, 69, 58, 0.18)",
                    }}
                    labelStyle={{ color: "#01453a", fontWeight: 600 }}
                  />
                  <Area type="monotone" dataKey="rate" stroke="#01453a" strokeWidth={3} fill="url(#monthlyGlow)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-3xl p-6 lg:col-span-3 lg:p-7" style={mintPanelStyle}>
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-[#01453a]/70">Distribution</p>
              <h3 className="mt-2 text-2xl font-semibold text-[#01453a]">Fresh vs Frozen mix</h3>
            </div>

            <div className="mt-6 flex justify-center">
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie
                    data={dashboard.distributionData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={62}
                    outerRadius={92}
                    paddingAngle={3}
                  >
                    {dashboard.distributionData.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} stroke={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "rgba(255, 255, 255, 0.96)",
                      border: "1px solid rgba(1,69,58,0.12)",
                      borderRadius: 16,
                      color: "#01453a",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-4 space-y-3">
              {dashboard.distributionData.map((item) => {
                const total = dashboard.distributionData.reduce((sum, current) => sum + current.value, 0);
                const percent = total ? Math.round((item.value / total) * 100) : 0;

                return (
                  <div key={item.name} className="flex items-center justify-between rounded-2xl border border-[#01453a]/8 bg-white/45 px-4 py-3">
                    <div className="flex items-center gap-3">
                      <span className="h-3 w-3 rounded-full" style={{ background: item.color }} />
                      <span className="text-sm text-[#01453a]/75">{item.name}</span>
                    </div>
                    <span className="text-sm font-semibold text-[#01453a]">{percent}%</span>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
          <div className="rounded-3xl p-6 lg:p-7" style={mintPanelStyle}>
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-[#01453a]/70">Protocol</p>
              <h3 className="mt-2 text-2xl font-semibold text-[#01453a]">Protocol effectiveness</h3>
            </div>

            <div className="mt-6 h-[320px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dashboard.protocolData} layout="vertical" margin={{ top: 6, right: 20, left: 130, bottom: 6 }}>
                  <XAxis type="number" domain={[0, 100]} stroke="rgba(1,69,58,0.55)" tickFormatter={(value) => `${value}%`} />
                  <YAxis type="category" dataKey="name" width={125} stroke="rgba(1,69,58,0.55)" tick={{ fill: "#01453a", fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      background: "rgba(255,255,255,0.96)",
                      border: "1px solid rgba(1,69,58,0.12)",
                      borderRadius: 16,
                      color: "#01453a",
                    }}
                  />
                  <Bar dataKey="rate" radius={[0, 14, 14, 0]}>
                    {dashboard.protocolData.map((entry, index) => (
                      <Cell key={entry.name} fill={ACCENTS[index % ACCENTS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-3xl p-6 lg:p-7" style={mintPanelStyle}>
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-[#01453a]/70">Embryo Grade</p>
              <h3 className="mt-2 text-2xl font-semibold text-[#01453a]">Success rate by grade bucket</h3>
            </div>

            <div className="mt-6 h-[320px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dashboard.gradeData} margin={{ top: 12, right: 20, left: 0, bottom: 6 }}>
                  <XAxis dataKey="name" stroke="rgba(1,69,58,0.55)" tickLine={false} axisLine={false} />
                  <YAxis stroke="rgba(1,69,58,0.55)" tickFormatter={(value) => `${value}%`} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{
                      background: "rgba(255,255,255,0.96)",
                      border: "1px solid rgba(1,69,58,0.12)",
                      borderRadius: 16,
                      color: "#01453a",
                    }}
                  />
                  <Bar dataKey="value" radius={[12, 12, 0, 0]}>
                    {dashboard.gradeData.map((entry, index) => (
                      <Cell key={entry.name} fill={["#38bdf8", "#8b5cf6", "#ec4899", "#10b981"][index % 4]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>

        <section className="rounded-3xl p-6 lg:p-7" style={mintPanelStyle}>
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-[#01453a]/70">Technicians</p>
              <h3 className="mt-2 text-2xl font-semibold text-[#01453a]">Operator leaderboard</h3>
            </div>
            <div className="rounded-full border border-[#01453a]/10 bg-white/55 px-3 py-2 text-xs text-[#01453a]/70">
              {dashboard.technicians.length} operators shown
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-5">
            {dashboard.technicians.map((tech) => (
              <div
                key={tech.name}
                className="rounded-3xl border border-[#01453a]/10 bg-white/45 p-5 shadow-[0_18px_40px_rgba(1,69,58,0.12)] transition-transform duration-200 hover:-translate-y-1"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h4 className="text-lg font-semibold text-[#01453a]">{tech.name}</h4>
                    <p className="mt-1 text-xs uppercase tracking-[0.24em] text-[#01453a]/50">{tech.transfers} transfers</p>
                  </div>
                  <span className="rounded-full border border-emerald-500/20 bg-emerald-500/12 px-2 py-1 text-[11px] font-semibold text-emerald-700">
                    {tech.successRate >= 60 ? "Top" : "Active"}
                  </span>
                </div>

                <div className="mt-4 space-y-4">
                  <div>
                    <div className="mb-2 flex items-center justify-between text-xs text-[#01453a]/60">
                      <span>Success rate</span>
                      <span className="font-semibold text-emerald-700">{tech.successRate.toFixed(1)}%</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-white/45">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${tech.successRate}%`,
                          background: "linear-gradient(90deg, #01453a, #10b981)",
                          boxShadow: "0 0 18px rgba(1, 69, 58, 0.35)",
                        }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <StatChip label="Avg Grade" value={tech.avgGrade.toFixed(1)} color="#01453a" />
                    <StatChip label="Avg CL" value={tech.avgCL.toFixed(1)} color="#10b981" />
                  </div>

                  <div className="rounded-2xl border border-[#01453a]/8 bg-white/45 px-4 py-3">
                    <div className="flex items-center justify-between text-xs uppercase tracking-[0.22em] text-[#01453a]/45">
                      <span>Pregnancies</span>
                      <span>Completed</span>
                    </div>
                    <div className="mt-2 text-2xl font-semibold text-[#01453a]">{tech.pregnancies}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {isLoading ? (
          <div className="rounded-2xl border border-cyan-300/20 bg-cyan-300/10 px-4 py-3 text-sm text-cyan-100">
            Loading dataset and building visual analytics...
          </div>
        ) : null}
      </div>
    </div>
  );
}

function SparkleBadge() {
  return <Sparkles className="h-3.5 w-3.5 text-cyan-300 drop-shadow-[0_0_12px_rgba(56,189,248,0.85)]" />;
}

function MetricPanel({ metric, iconIndex }: { metric: MetricCard; iconIndex: number }) {
  const accent = metric.accent;

  return (
    <div
      className="relative overflow-hidden rounded-3xl p-5 transition-all duration-300 hover:-translate-y-1"
      style={{
        background: "rgba(255, 255, 255, 0.06)",
        border: `1px solid ${accent}24`,
        backdropFilter: "blur(34px) saturate(145%)",
        boxShadow: `0 20px 50px ${accent}22, inset 0 1px 0 rgba(255,255,255,0.08)`,
      }}
    >
      <div
        className="absolute inset-0 opacity-0 transition-opacity duration-300 hover:opacity-100"
        style={{ background: `radial-gradient(circle at top right, ${accent}22, transparent 55%)` }}
      />

      <div className="relative flex items-center justify-between">
        <div className="rounded-2xl border border-white/10 bg-white/6 p-3" style={{ boxShadow: `0 0 26px ${accent}30` }}>
          {iconIndex === 0 && <Users className="h-6 w-6" style={{ color: accent }} />}
          {iconIndex === 1 && <TrendingUp className="h-6 w-6" style={{ color: accent }} />}
          {iconIndex === 2 && <ShieldCheck className="h-6 w-6" style={{ color: accent }} />}
          {iconIndex === 3 && <Droplets className="h-6 w-6" style={{ color: accent }} />}
          {iconIndex === 4 && <Award className="h-6 w-6" style={{ color: accent }} />}
        </div>

        <span className="rounded-full border border-white/10 bg-white/6 px-2.5 py-1 text-[11px] font-semibold text-white/70">
          {metric.change}
        </span>
      </div>

      <div className="relative mt-5 space-y-1">
        <div className="text-3xl font-semibold tracking-tight text-white">{metric.value}</div>
        <div className="text-xs uppercase tracking-[0.24em] text-white/55">{metric.title}</div>
      </div>

      <div className="relative mt-4 h-2 overflow-hidden rounded-full bg-white/8">
        <div
          className="h-full rounded-full"
          style={{
            width: `${Math.max(4, Math.min(100, metric.progress))}%`,
            background: `linear-gradient(90deg, ${accent}, #ffffff)`,
            boxShadow: `0 0 18px ${accent}88`,
          }}
        />
      </div>
    </div>
  );
}

function StatChip({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="rounded-2xl border border-white/8 bg-white/4 px-3 py-3">
      <div className="text-[11px] uppercase tracking-[0.24em] text-white/45">{label}</div>
      <div className="mt-2 text-lg font-semibold text-white" style={{ color }}>
        {value}
      </div>
    </div>
  );
}